"""
AWS CloudWatch monitoring module for ADPA.
"""

from .monitor import CloudWatchMonitor

__all__ = ['CloudWatchMonitor']